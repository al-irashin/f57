// Включение консоли Ctrl+Shift+Y

// Программа которая проверяет склько вам лет
// let a = prompt('сколько вам лет?')
// if (a == 18){
//     alert('пока постойте')
// }
// else if (a < 18) {
//     alert('не проходите')
// }
// else if ( a > 18) {
//     alert('проходите')
// }


// Программа которая сравнивает два числа и если они равны добавляет к сумме 1000.
// let a  = Number(prompt())
// let b  = Number(prompt())
// if (a === b) {
// let sum = (a + b) + 1000
// alert(sum)
// }


// let a = prompt('в каком году закончится 2023 год')
// if (a == 2023) 
// {alert('красава')}
// else if (a < 2023) 
// {alert('не верно')}
// else if (a > 2023) 
// {alert('ну ты загнул')}


// Программа которая проверяет явлвется число четным или нет.
// let a = prompt()
// if (a % 2 === 0)
// {alert('четное')}
// else {alert('нечетное')}


// let a = 5
// let b = 3
// alert(a % b)


// Задача: вывести числа от 1 до 10 вкючительно.
// let count = 1
// while (count <= 10) {
//     console.log(count);
//     alert(count++);
// }


// Задача: найти первое число в последоваьельности, которое делится на 2 и 3 одновременно.
// let number = 1;
// let found = false;
// while (!found) {
//     if (number % 2 === 0 && number % 3 === 0) {
//         console.log(number);
//         found = true;
//     }
//     number++;
// }


// Задача: подсчет суммы покупок в магазине. НЕ РАБОТАЕТ. Выдает общую сумму 0$

let totalPrice = 0
let i = 0
const prices = [3000,1700,2800,1500,1000]

while (i < prices.length) {
    totalPrice += prices[i]
    i++
}
console.log(totalPrice + '$')
console.log(`Стоимость ${totalPrice}$`)

// Задача: Ожидание окончания процессов.
// let responseREceived = false
// let timeout = 0
// while (!responseREceived && timeout < 5000 ) {
//     timeout += 100
// }
// if (responseREceived) {
//     console.log('true')
// }
// else {
//     console.log('false')
// }


// Цикл do...while. Вывести цифры от 0 до 5
// let i = 0
// do {
//     console.log(i)
//     i++
// }while (i <= 5)

// Еще пример:
// let input
// do {
//     input = prompt('введи число больше или равно 10')
// }while (input < 10)
// console.log(input)


// Цикл FOR - вывести цифры от 1 до 10.
// (начало; условие; шаг){
//     Тело
// }
// for (let i = 0; i < 10; i++) {
//     console.log(i)
// }


// Подсчет введенных цифр (типа калькулятора) ПРЕРЫВАНИЕ ЦИКЛА
// let i = 0
// while (true) { 
//     let value = +prompt('Число')
//     if (!value) break
//     i += value
// }
// console.log(i)


// ПЕРЕХОД К СЛЕДУЮЩЕЙ ИТЕРАЦИИ - выводим числа от 1 до 10 которые не делятся на 2.
// for (let i = 0; i < 10; i++) {
//     if (i % 2 == 0) continue
//     console.log(i)
// }


// Вывести сумму всех чисел от 1 до 20.
// let sum = 0
// for (let i = 1; i <= 20; i++){
//     sum += i
// }
// console.log(sum)


// Вывести массив данных.
// const colors = ['Красный','Желтый','Синий']
// for (let i = 0; i < colors.length;i++) {
//     console.log(colors[i])
// }


// ЛОГИЧЕСКИЕ ОПЕРАТОРЫ
// || - или
// && - или
// ! - не


// МАССИВЫ
// Пустой массив записаный по разному:
// let arr = new Array()
// let arr = []


// Подставляем в квадратные скобки число 0 или 1 или 2 и получем ответ
// let fru = ['Эрик','Кот','Ноутбук']
// console.log(fru[])


// Вывести количество пользователей имена которых начинаются на А.
// const users = [
//     {name: 'Erik', age: 25},
//     {name: 'Yota', age: 30},
//     {name: 'Alice', age: 12},
//     {name: 'Mark', age: 99},
//     {name: 'Adalinda', age: 123},
//     {name: 'Grim', age: 54},
//     {name: 'Allex', age: 34},
//     {name: 'Blade', age: 22},
//     {name: 'Strelok', age: 20},
// ]
// let count = 0
// const targetLetter = "A"
// for (let i = 0; i < users.length; i++) {
//     const firstLetter = users[i].name.charAt(0).toUpperCase()
//     if (firstLetter === targetLetter) {
//         count++;
//     }
// }
// console.log(count)


// Задача: подсчет суммы покупок в магазине. НЕ РАБОТАЕТ. Выдает общую сумму 0$

// let totalPrice = 0
// let i = 0
// const prices = [3000,1700,2800,1500,1000]

// while (i < prices.length) {
//     totalPrice += prices[i]
//     i++
// }
// console.log(totalPrice + '$')
// console.log(`Стоимость ${totalPrice}$`)